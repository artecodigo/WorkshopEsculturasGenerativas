###ofxMarchingCubes
by Andre Sier, july 2012

/*
 
openframeworks marching cubes implementation by andré sier
[http://s373.net/code/marchingcubes](http://s373.net/code/marchingcubes)
 
Marching cubes implementation after Paul Bourke polygonize voxel.
 
[http://paulbourke.net/geometry/polygonise/](http://paulbourke.net/geometry/polygonise/)

201207 - of version
 
201004 - processing version
 
code released under [LGPL3.0 . http://www.gnu.org/licenses/lgpl-3.0.txt)](http://www.gnu.org/licenses/lgpl-3.0.txt)
 
copyright 2012, Andre Sier http://s373.net
 
 
 */
